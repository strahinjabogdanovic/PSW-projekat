﻿using PswProject.dto;
using PswProject.model;
using PswProject.repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.DirectoryServices.AccountManagement;
using Microsoft.AspNetCore.Authentication;
using Microsoft.EntityFrameworkCore;

namespace PswProject.service
{
    public class UserService
    {
        public MyDbContext dbContext { get; set; }
        private UserRepository userRepository { get; set; }

        private UserSqlRepository userSqlRepository { get; set; }

        public UserService(UserSqlRepository userSqlRepository) {
            userSqlRepository = new UserSqlRepository();
        }
        public UserService() { }

        public UserService(UserRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        public Boolean registration(RegistrationDTO registrationDTO) 
        {
            User user = new User(registrationDTO);
            
            //user.Role = Role.PATIENT;
            UserSqlRepository.Add(user, dbContext);

            return true;
	    }

    }
}
